VSR TAXI Premium - Project files generated.

Backend: ./backend
Frontend: ./frontend

Instructions:
1. Backend:
   cd backend
   npm install
   cp .env.example .env
   fill .env values
   npm run dev

2. Frontend:
   cd frontend
   npm install
   cp .env.example .env
   fill .env values
   npm run dev

Open frontend (Vite) url (usually http://loca.lhost:5173)
Backend runs on http://localhost:5000
