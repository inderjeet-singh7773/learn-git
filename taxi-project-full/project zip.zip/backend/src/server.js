require("dotenv").config();
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const http = require("http");

const app = express();

// MIDDLEWARE
app.use(cors());
app.use(express.json());

// ROUTES (⭐ Yaha likhna hai)
app.use("/api/auth", require("./routes/auth"));

// CREATE SERVER
const server = http.createServer(app);

// SOCKET INIT
const socket = require("./socket");
socket.init(server);

// DATABASE + SERVER START
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("MongoDB connected");

    const PORT = process.env.PORT || 5000;

    server.listen(PORT, () => {
      console.log("Server running on", PORT);
    });
  })
  .catch((err) => console.error(err));
