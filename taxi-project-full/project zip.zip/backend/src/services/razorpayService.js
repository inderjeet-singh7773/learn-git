// const Razorpay = require('razorpay');
// const instance = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });

// exports.createOrder = async ({ amount, currency='INR', receipt }) => {
//   const options = { amount: Math.round(amount * 100), currency, receipt };
//   return instance.orders.create(options);
// }

// for test only

module.exports = {};
