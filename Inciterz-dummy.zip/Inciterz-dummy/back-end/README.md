# Node.js Backend Architecture - Sample Project

## Quick Start

1. Copy `.env.example` to `.env` and fill your `MONGO_URL`.
2. Install dependencies:
   ```
   npm install
   ```
3. Run (development):
   ```
   npm run dev
   ```
4. Open `http://localhost:8000/api/users` (GET) to see sample response.

## Folder Structure

```
backend/
 ├── src/
 │   ├── routes/
 │   │     └── user.routes.js
 │   ├── controllers/
 │   │     └── user.controller.js
 │   ├── services/
 │   │     └── user.service.js
 │   ├── models/
 │   │     └── user.model.js
 │   ├── middleware/
 │   │     └── auth.middleware.js
 │   ├── config/
 │   │     ├── db.js
 │   │     └── env.js
 │   ├── utils/
 │   │     └── apiResponse.js
 │   ├── app.js
 │   └── server.js
 ├── .env.example
 └── package.json
```
