import User from "../models/user.model.js";

export const UserService = {
  getAllUsers: async () => {
    return await User.find().lean();
  },

  createUser: async (data) => {
    return await User.create(data);
  }
};
