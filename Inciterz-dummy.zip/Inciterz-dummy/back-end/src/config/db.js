import mongoose from "mongoose";
import dotenv from "dotenv";
dotenv.config();

const MONGO_URL = process.env.MONGO_URL || "mongodb://localhost:27017/node_backend_db";

mongoose.connect(MONGO_URL, {
  // useNewUrlParser and useUnifiedTopology are default in mongoose v6+
})
  .then(() => console.log("DB Connected"))
  .catch((err) => console.error("DB Connection Error:", err));
