import { UserService } from "../services/user.service.js";
import { ApiResponse } from "../utils/apiResponse.js";

export const getUsers = async (req, res) => {
  try {
    const users = await UserService.getAllUsers();
    return res.status(200).json(new ApiResponse(200, users, "Users fetched successfully"));
  } catch (err) {
    return res.status(500).json({ message: "Server error", error: err.message });
  }
};

export const createUser = async (req, res) => {
  try {
    const payload = req.body;
    const user = await UserService.createUser(payload);
    return res.status(201).json(new ApiResponse(201, user, "User created successfully"));
  } catch (err) {
    return res.status(500).json({ message: "Server error", error: err.message });
  }
};
